"""
mcp_client.py
-------------
A simple MCP client that:
  1. Starts the MCP server as a subprocess
  2. Discovers the server's tools
  3. Passes those tools to OpenAI's chat API
  4. Lets OpenAI decide when to call a tool
  5. Runs the tool on the MCP server and returns the result

Install dependencies:
  pip install mcp openai

Usage:
  python mcp_client.py
"""

import asyncio
import json
import os
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from openai import OpenAI

# ── Configuration ─────────────────────────────────────────────────────────────

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "YOUR_OPENAI_KEY_HERE")
SERVER_SCRIPT  = "mcp_server.py"   # Path to your MCP server script


# ── Helper: convert MCP tools → OpenAI tool format ───────────────────────────

def mcp_tools_to_openai(mcp_tools):
    """
    OpenAI expects tools in this shape:
      {
        "type": "function",
        "function": {
          "name": "...",
          "description": "...",
          "parameters": { ...JSON Schema... }
        }
      }
    """
    openai_tools = []
    for t in mcp_tools:
        openai_tools.append({
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description,
                "parameters": t.inputSchema,
            },
        })
    return openai_tools


# ── Main client logic ─────────────────────────────────────────────────────────

async def run():
    client = OpenAI(api_key=OPENAI_API_KEY)

    # 1. Start the MCP server as a subprocess communicating over stdio
    server_params = StdioServerParameters(
        command="python",
        args=[SERVER_SCRIPT],
    )

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:

            # 2. Initialize the MCP session
            await session.initialize()

            # 3. Discover what tools the server has
            tools_response = await session.list_tools()
            openai_tools   = mcp_tools_to_openai(tools_response.tools)

            print("=== Available MCP Tools ===")
            for t in tools_response.tools:
                print(f"  • {t.name}: {t.description}")
            print()

            # 4. Simple chat loop
            messages = []
            print("Chat with OpenAI + MCP tools. Type 'quit' to exit.\n")

            while True:
                user_input = input("You: ").strip()
                if user_input.lower() in ("quit", "exit"):
                    break
                if not user_input:
                    continue

                messages.append({"role": "user", "content": user_input})

                # 5. Send to OpenAI with the available tools
                response = client.chat.completions.create(
                    model="gpt-4o",
                    messages=messages,
                    tools=openai_tools,
                    tool_choice="auto",   # let the model decide when to use tools
                )

                message = response.choices[0].message

                # 6. If OpenAI wants to call a tool, handle it
                while message.tool_calls:
                    # Add assistant's decision to message history
                    messages.append(message)

                    # Process each tool call
                    for tool_call in message.tool_calls:
                        func_name = tool_call.function.name
                        func_args = json.loads(tool_call.function.arguments)

                        print(f"  [Calling tool: {func_name}({func_args})]")

                        # 7. Execute the tool on the MCP server
                        result = await session.call_tool(func_name, func_args)
                        tool_output = result.content[0].text

                        print(f"  [Tool result: {tool_output}]")

                        # 8. Feed the result back to OpenAI
                        messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": tool_output,
                        })

                    # Let OpenAI respond again now that it has the tool results
                    response = client.chat.completions.create(
                        model="gpt-4o",
                        messages=messages,
                        tools=openai_tools,
                        tool_choice="auto",
                    )
                    message = response.choices[0].message

                # 9. Print the final response
                final_text = message.content or ""
                messages.append({"role": "assistant", "content": final_text})
                print(f"\nAssistant: {final_text}\n")


if __name__ == "__main__":
    asyncio.run(run())
